# Salesforce Adapter apex classes

Files for the implementation of salesforce adapter.
This is a dummy adapter and does not perform an actual call to any gateway.
These classes work on release version 230 and above.

## Deployment

The classes need to be compiled in this order:

```
1. SalesforceValidationException.apex
2. SalesforceAdapter.apex
```
