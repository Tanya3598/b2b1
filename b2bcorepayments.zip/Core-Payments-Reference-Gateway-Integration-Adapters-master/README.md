# Core-Payments-Reference-Gateway-Integration-Adapter
  
This repository contains reference implementations for different gateways along with one dummy implementation called Salesforce adapter. This code works with release version 230 and above.
